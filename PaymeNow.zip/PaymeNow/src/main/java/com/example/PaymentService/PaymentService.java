package com.example.PaymentService;

public interface PaymentService {
	public void processPayment(int amount);
}
